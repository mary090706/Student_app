from flask import Flask, request, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Database setup
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///students.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Database model
class Student(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100))
    course = db.Column(db.String(100))
    year = db.Column(db.String(10))

with app.app_context():
    db.create_all()

# Routes
@app.route('/')
def home():
    return redirect(url_for('list_students'))

@app.route('/add', methods=['GET', 'POST'])
def add_student():
    if request.method == 'POST':
        name = request.form['name']
        course = request.form['course']
        year = request.form['year']
        new_student = Student(name=name, course=course, year=year)
        db.session.add(new_student)
        db.session.commit()
        return redirect(url_for('list_students'))
    return render_template('add.html')

@app.route('/list')
def list_students():
    students = Student.query.all()
    return render_template('list.html', students=students)

@app.route('/delete/<int:id>')
def delete_student(id):
    student = Student.query.get(id)
    if student:
        db.session.delete(student)
        db.session.commit()
    return redirect(url_for('list_students'))

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
